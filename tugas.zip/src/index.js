import "./script/script.js";
import "./style/style.css";
import "./style/animation.css";
import "./style/responsive.css";
